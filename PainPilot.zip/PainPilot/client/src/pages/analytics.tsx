import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { generateAndDownloadReport } from "@/lib/pdfGenerator";
import type { PainEntry } from "@shared/schema";

interface PainTrend {
  date: string;
  avgPain: number;
}

interface AreaDistribution {
  area: string;
  percentage: number;
}

interface AnalyticsData {
  totalEntries: number;
  averagePain: number;
  painFreeDays: number;
  commonArea: string;
  areaDistribution: AreaDistribution[];
  painTrends: PainTrend[];
}

export default function Analytics() {
  const [reportLoading, setReportLoading] = useState(false);
  const [selectedDays, setSelectedDays] = useState(7);
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: analytics, isLoading: analyticsLoading, error: analyticsError, refetch } = useQuery<AnalyticsData>({
    queryKey: ["/api/pain-analytics", selectedDays],
    queryFn: async () => {
      const res = await fetch(`/api/pain-analytics?days=${selectedDays}`, {
        credentials: "include",
      });
      if (!res.ok) {
        throw new Error("Failed to fetch analytics");
      }
      return res.json();
    },
    enabled: isAuthenticated,
    retry: false,
  });

  useEffect(() => {
    if (analyticsError && isUnauthorizedError(analyticsError)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [analyticsError, toast]);

  const { data: painEntries, error: entriesError } = useQuery<PainEntry[]>({
    queryKey: ["/api/pain-entries"],
    enabled: !!analytics && analytics.totalEntries > 0,
    retry: false,
  });

  useEffect(() => {
    if (entriesError && isUnauthorizedError(entriesError)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [entriesError, toast]);

  const handleDaysChange = (days: number) => {
    setSelectedDays(days);
  };

  useEffect(() => {
    if (isAuthenticated) {
      refetch();
    }
  }, [selectedDays, isAuthenticated, refetch]);

  const downloadReport = async () => {
    if (!analytics || !painEntries) return;
    
    setReportLoading(true);
    try {
      const analyticsData = {
        totalEntries: analytics.totalEntries,
        averagePain: analytics.averagePain,
        painFreeDays: analytics.painFreeDays,
        areaDistribution: analytics.areaDistribution || [],
        dailyTrends: analytics.painTrends?.map((trend: PainTrend) => ({
          date: trend.date,
          averagePain: trend.avgPain,
          mood: 'good'
        })) || []
      };

      await generateAndDownloadReport(
        painEntries,
        analyticsData,
        chartRef.current || undefined
      );

      toast({
        title: "Report Generated",
        description: "Your pain report PDF has been downloaded successfully!",
      });
    } catch (error) {
      console.error("PDF generation error:", error);
      toast({
        title: "Error",
        description: "Failed to generate PDF report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setReportLoading(false);
    }
  };

  if (isLoading || analyticsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-semibold text-gray-600">Loading analytics...</p>
        </div>
      </div>
    );
  }

  if (!analytics || analytics.totalEntries === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto p-4">
          <Card className="shadow-lg border-gray-100">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">No Pain Data Available</h2>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                Start logging your pain entries to see detailed analytics and patterns.
              </p>
              <Button
                onClick={() => window.location.href = "/pain-log"}
                className="gradient-bg text-white hover:opacity-90"
                data-testid="button-log-first-entry"
              >
                Log Your First Entry
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Pain Analytics</h1>
            <p className="text-gray-600">Understand your pain patterns and trends</p>
          </div>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              className={selectedDays === 7 ? "text-primary bg-purple-50" : "text-gray-600 hover:bg-gray-50"}
              onClick={() => handleDaysChange(7)}
              data-testid="button-7-days"
            >
              7 Days
            </Button>
            <Button 
              variant="outline" 
              className={selectedDays === 30 ? "text-primary bg-purple-50" : "text-gray-600 hover:bg-gray-50"}
              onClick={() => handleDaysChange(30)}
              data-testid="button-30-days"
            >
              30 Days
            </Button>
            <Button 
              variant="outline" 
              className={selectedDays === 90 ? "text-primary bg-purple-50" : "text-gray-600 hover:bg-gray-50"}
              onClick={() => handleDaysChange(90)}
              data-testid="button-90-days"
            >
              90 Days
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="shadow-lg border-gray-100">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-blue-600" data-testid="text-total-entries">{analytics.totalEntries}</div>
              <div className="text-sm text-gray-600">Total Entries</div>
            </CardContent>
          </Card>
          <Card className="shadow-lg border-gray-100">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-red-600" data-testid="text-avg-pain">{analytics.averagePain.toFixed(1)}/10</div>
              <div className="text-sm text-gray-600">Average Pain</div>
            </CardContent>
          </Card>
          <Card className="shadow-lg border-gray-100">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-green-600" data-testid="text-pain-free-days">{analytics.painFreeDays}</div>
              <div className="text-sm text-gray-600">Pain-Free Days</div>
            </CardContent>
          </Card>
          <Card className="shadow-lg border-gray-100">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-purple-600" data-testid="text-common-area">{analytics.commonArea || 'N/A'}</div>
              <div className="text-sm text-gray-600">Most Common Area</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="shadow-lg border-gray-100">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Pain Trends (Last {selectedDays} Days)</h3>
              <div ref={chartRef} className="h-72 bg-gray-50 rounded-xl p-4">
                {analytics.painTrends && analytics.painTrends.length > 0 ? (
                  <div className="relative h-full">
                    <div className="absolute inset-0 flex items-end justify-between px-4 pb-8">
                      {analytics.painTrends.slice(-7).map((trend: PainTrend, index: number) => {
                        const height = Math.max((trend.avgPain / 10) * 200, 20);
                        const color = trend.avgPain <= 3 ? "bg-green-400" : 
                                     trend.avgPain <= 6 ? "bg-yellow-400" : "bg-red-400";
                        const textColor = trend.avgPain <= 3 ? "text-green-600" : 
                                         trend.avgPain <= 6 ? "text-yellow-600" : "text-red-600";
                        
                        return (
                          <div key={`trend-${index}-${trend.date}`} className="flex flex-col items-center space-y-2">
                            <div className={`w-8 ${color} rounded-t`} style={{ height: `${height}px` }}></div>
                            <span className="text-xs text-gray-600">
                              {new Date(trend.date).toLocaleDateString('en-US', { weekday: 'short' })}
                            </span>
                            <span className={`text-xs font-bold ${textColor}`}>
                              {trend.avgPain.toFixed(1)}/10
                            </span>
                          </div>
                        );
                      })}
                    </div>
                    <div className="absolute top-4 right-4 flex items-center space-x-4 text-xs">
                      <div className="flex items-center space-x-1">
                        <div className="w-3 h-3 bg-red-400 rounded"></div>
                        <span>Pain Level</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-500">
                    <div className="text-center">
                      <svg className="w-12 h-12 mx-auto mb-2 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                      </svg>
                      <p>No trend data available</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-gray-100">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Pain Areas Distribution</h3>
              <div className="space-y-4">
                {analytics.areaDistribution && analytics.areaDistribution.length > 0 ? (
                  analytics.areaDistribution.slice(0, 5).map((area: AreaDistribution, index: number) => {
                    const colors = ["bg-red-500", "bg-orange-500", "bg-yellow-500", "bg-green-500", "bg-blue-500"];
                    const bgColor = colors[index % colors.length];
                    
                    return (
                      <div key={`area-${area.area}-${index}`}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <div className={`w-4 h-4 ${bgColor} rounded`}></div>
                            <span className="font-medium text-gray-900 capitalize">
                              {area.area?.replace('-', ' ') || 'Unknown Area'}
                            </span>
                          </div>
                          <span className="font-bold text-gray-900">{area.percentage}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`${bgColor} h-2 rounded-full transition-all duration-500`}
                            style={{ width: `${area.percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    <svg className="w-12 h-12 mx-auto mb-2 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                    <p>No area distribution data</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-center">
          <Button
            onClick={downloadReport}
            disabled={reportLoading || !analytics || !painEntries}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
            data-testid="button-download-report"
          >
            {reportLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Generating PDF...
              </>
            ) : (
              <>
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                Download PDF Report
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
