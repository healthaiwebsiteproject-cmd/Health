import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import PainIntensitySlider from "@/components/pain-intensity-slider";

const painLogSchema = z.object({
  painArea: z.string().min(1, "Please select a pain area"),
  intensity: z.number().min(0).max(10),
  painType: z.string().min(1, "Please select a pain type"),
  duration: z.string().min(1, "Please select duration"),
  triggers: z.string().optional(),
  notes: z.string().optional(),
  mood: z.string().optional(),
});

type PainLogForm = z.infer<typeof painLogSchema>;

export default function PainLog() {
  const [isRecording, setIsRecording] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const form = useForm<PainLogForm>({
    resolver: zodResolver(painLogSchema),
    defaultValues: {
      painArea: "",
      intensity: 5,
      painType: "",
      duration: "",
      triggers: "",
      notes: "",
      mood: "",
    },
  });

  const createPainEntry = useMutation({
    mutationFn: async (data: PainLogForm) => {
      await apiRequest("POST", "/api/pain-entries", data);
    },
    onSuccess: () => {
      toast({
        title: "Pain Entry Logged",
        description: "Your pain entry has been recorded successfully.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/pain-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/pain-analytics"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to log pain entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PainLogForm) => {
    createPainEntry.mutate(data);
  };

  const startVoiceInput = () => {
    setIsRecording(true);
    
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';
      
      recognition.onstart = () => {
        toast({
          title: "Voice Input Active",
          description: "Speak now to describe your pain...",
        });
      };
      
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        form.setValue('notes', form.getValues('notes') + ' ' + transcript);
        toast({
          title: "Voice Input Captured",
          description: "Your voice input has been added to notes.",
        });
        setIsRecording(false);
      };
      
      recognition.onerror = () => {
        toast({
          title: "Voice Input Error",
          description: "Could not capture voice input. Please try again.",
          variant: "destructive",
        });
        setIsRecording(false);
      };
      
      recognition.onend = () => {
        setIsRecording(false);
      };
      
      recognition.start();
    } else {
      toast({
        title: "Voice Input Not Supported",
        description: "Your browser doesn't support voice input.",
        variant: "destructive",
      });
      setIsRecording(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-semibold text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <Card className="shadow-lg border-gray-100">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Log Your Pain</h1>
                <p className="text-gray-600">Track your pain to better understand patterns</p>
              </div>
              <Button
                type="button"
                onClick={startVoiceInput}
                disabled={isRecording}
                className="gradient-bg text-white hover:opacity-90"
              >
                <svg className={`w-4 h-4 mr-2 ${isRecording ? "voice-pulse" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
                {isRecording ? "Recording..." : "Voice Input"}
              </Button>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Left Column */}
                  <div className="space-y-6">
                    {/* Pain Area */}
                    <FormField
                      control={form.control}
                      name="painArea"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-gray-700">Pain Area</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select area..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="head">Head/Headache</SelectItem>
                              <SelectItem value="neck">Neck</SelectItem>
                              <SelectItem value="shoulders">Shoulders</SelectItem>
                              <SelectItem value="upper-back">Upper Back</SelectItem>
                              <SelectItem value="lower-back">Lower Back</SelectItem>
                              <SelectItem value="arms">Arms</SelectItem>
                              <SelectItem value="hands">Hands/Wrists</SelectItem>
                              <SelectItem value="chest">Chest</SelectItem>
                              <SelectItem value="abdomen">Abdomen</SelectItem>
                              <SelectItem value="hips">Hips</SelectItem>
                              <SelectItem value="legs">Legs</SelectItem>
                              <SelectItem value="knees">Knees</SelectItem>
                              <SelectItem value="feet">Feet/Ankles</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Pain Intensity */}
                    <FormField
                      control={form.control}
                      name="intensity"
                      render={({ field }) => (
                        <FormItem>
                          <PainIntensitySlider
                            value={field.value}
                            onChange={field.onChange}
                          />
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Pain Type */}
                    <FormField
                      control={form.control}
                      name="painType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-gray-700">Pain Type</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select type..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="sharp">Sharp/Stabbing</SelectItem>
                              <SelectItem value="dull">Dull/Aching</SelectItem>
                              <SelectItem value="burning">Burning</SelectItem>
                              <SelectItem value="throbbing">Throbbing</SelectItem>
                              <SelectItem value="cramping">Cramping</SelectItem>
                              <SelectItem value="shooting">Shooting</SelectItem>
                              <SelectItem value="tingling">Tingling</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Duration */}
                    <FormField
                      control={form.control}
                      name="duration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-gray-700">Duration</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select duration..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="less-1h">Less than 1 hour</SelectItem>
                              <SelectItem value="1-3h">1-3 hours</SelectItem>
                              <SelectItem value="3-6h">3-6 hours</SelectItem>
                              <SelectItem value="6-12h">6-12 hours</SelectItem>
                              <SelectItem value="more-12h">More than 12 hours</SelectItem>
                              <SelectItem value="all-day">All day</SelectItem>
                              <SelectItem value="ongoing">Ongoing (multiple days)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Right Column */}
                  <div className="space-y-6">
                    {/* Triggers */}
                    <FormField
                      control={form.control}
                      name="triggers"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-gray-700">Triggers (optional)</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Weather, stress, activity, medication..."
                              className="resize-none h-20"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Additional Notes */}
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-gray-700">Additional Notes</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="How does this pain affect you? Any additional details..."
                              className="resize-none h-32"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Mood Indicator */}
                    <FormField
                      control={form.control}
                      name="mood"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-gray-700">How are you feeling today?</FormLabel>
                          <div className="grid grid-cols-4 gap-3">
                            {[
                              { value: "good", emoji: "😊", label: "Good", color: "hover:border-green-400 hover:bg-green-50" },
                              { value: "okay", emoji: "😐", label: "Okay", color: "hover:border-yellow-400 hover:bg-yellow-50" },
                              { value: "sad", emoji: "😔", label: "Sad", color: "hover:border-orange-400 hover:bg-orange-50" },
                              { value: "anxious", emoji: "😰", label: "Anxious", color: "hover:border-red-400 hover:bg-red-50" },
                            ].map((mood) => (
                              <button
                                key={mood.value}
                                type="button"
                                onClick={() => field.onChange(mood.value)}
                                className={`py-3 px-4 border-2 rounded-xl transition-colors text-center ${
                                  field.value === mood.value
                                    ? "border-primary bg-primary/10"
                                    : `border-gray-200 ${mood.color}`
                                }`}
                              >
                                <div className="text-2xl mb-1">{mood.emoji}</div>
                                <div className="text-xs font-medium">{mood.label}</div>
                              </button>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Submit Button */}
                    <Button
                      type="submit"
                      disabled={createPainEntry.isPending}
                      className="w-full gradient-bg text-white py-4 hover:opacity-90"
                    >
                      {createPainEntry.isPending ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                          Logging Entry...
                        </>
                      ) : (
                        <>
                          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Log Pain Entry
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
