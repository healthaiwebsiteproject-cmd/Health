import { useState, useEffect, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import BreathingExercise from "@/components/breathing-exercise";

interface TherapyModule {
  id: string;
  title: string;
  description: string;
  type: string;
  category: string;
  icon: string;
  gradient: string;
  borderColor: string;
  duration?: number;
  audioUrl?: string;
}

const therapyModules: TherapyModule[] = [
  {
    id: "478-breathing",
    title: "4-7-8 Breathing",
    description: "Classic calming breath technique",
    type: "breathing",
    category: "meditation",
    icon: "wind",
    gradient: "from-purple-50 to-blue-50",
    borderColor: "border-purple-100",
    duration: 10,
  },
  {
    id: "box-breathing",
    title: "Box Breathing",
    description: "4-count equal breathing pattern",
    type: "breathing",
    category: "meditation",
    icon: "square",
    gradient: "from-green-50 to-teal-50",
    borderColor: "border-green-100",
    duration: 10,
  },
  {
    id: "progressive-relaxation",
    title: "Progressive Muscle Relaxation",
    description: "Systematic tension and release",
    type: "relaxation",
    category: "meditation",
    icon: "compress",
    gradient: "from-orange-50 to-yellow-50",
    borderColor: "border-orange-100",
    duration: 15,
  },
  {
    id: "guided-meditation",
    title: "Guided Pain Meditation",
    description: "Mindfulness for pain management",
    type: "meditation",
    category: "meditation",
    icon: "brain",
    gradient: "from-indigo-50 to-purple-50",
    borderColor: "border-indigo-100",
    duration: 10,
  },
  {
    id: "nature-sounds",
    title: "Nature Sounds",
    description: "Relaxing forest and rain sounds",
    type: "sound",
    category: "sound",
    icon: "music",
    gradient: "from-emerald-50 to-green-50",
    borderColor: "border-emerald-100",
    duration: 15,
    audioUrl: "https://cdn.freesound.org/previews/527/527409_2193266-lq.mp3",
  },
  {
    id: "ocean-waves",
    title: "Ocean Waves",
    description: "Calming ocean and beach sounds",
    type: "sound",
    category: "sound",
    icon: "music",
    gradient: "from-cyan-50 to-blue-50",
    borderColor: "border-cyan-100",
    duration: 15,
    audioUrl: "https://cdn.freesound.org/previews/473/473525_7193358-lq.mp3",
  },
  {
    id: "tibetan-bowls",
    title: "Tibetan Singing Bowls",
    description: "Healing bowl vibrations",
    type: "sound",
    category: "sound",
    icon: "music",
    gradient: "from-amber-50 to-orange-50",
    borderColor: "border-amber-100",
    duration: 10,
    audioUrl: "https://cdn.freesound.org/previews/362/362652_91313-lq.mp3",
  },
  {
    id: "gentle-stretching",
    title: "Gentle Stretching",
    description: "Low-impact stretching routine",
    type: "exercise",
    category: "exercise",
    icon: "dumbbell",
    gradient: "from-rose-50 to-pink-50",
    borderColor: "border-rose-100",
    duration: 15,
  },
  {
    id: "yoga-basics",
    title: "Yoga Basics",
    description: "Beginner-friendly yoga poses",
    type: "exercise",
    category: "exercise",
    icon: "dumbbell",
    gradient: "from-violet-50 to-purple-50",
    borderColor: "border-violet-100",
    duration: 20,
  },
  {
    id: "chair-exercises",
    title: "Chair Exercises",
    description: "Seated exercises for limited mobility",
    type: "exercise",
    category: "exercise",
    icon: "dumbbell",
    gradient: "from-sky-50 to-blue-50",
    borderColor: "border-sky-100",
    duration: 10,
  },
];

export default function Therapy() {
  const [activeCategory, setActiveCategory] = useState("meditation");
  const [activeExercise, setActiveExercise] = useState<string | null>(null);
  const [activeSoundModuleId, setActiveSoundModuleId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  const activeSoundModule = activeSoundModuleId 
    ? therapyModules.find(m => m.id === activeSoundModuleId) || null 
    : null;

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleAudioError = useRef(false);
  
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (currentAudioUrl) {
      audio.src = currentAudioUrl;
      audio.loop = true;
      handleAudioError.current = false;
      
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
          })
          .catch((error) => {
            if (error.name !== "AbortError" && !handleAudioError.current) {
              handleAudioError.current = true;
              console.error("Error playing audio:", error);
              setIsPlaying(false);
              setCurrentAudioUrl(null);
              setActiveSoundModuleId(null);
            }
          });
      }
    } else {
      audio.pause();
      audio.currentTime = 0;
      audio.src = "";
      setIsPlaying(false);
    }
  }, [currentAudioUrl]);

  useEffect(() => {
    const audio = audioRef.current;
    return () => {
      if (audio) {
        audio.pause();
        audio.src = "";
      }
    };
  }, []);

  const createTherapySession = useMutation({
    mutationFn: async (sessionData: { type: string; duration?: number; completed: boolean }) => {
      await apiRequest("POST", "/api/therapy-sessions", sessionData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/therapy-sessions"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error("Failed to log therapy session:", error);
    },
  });

  const filteredModules = therapyModules.filter(module => module.category === activeCategory);

  const getIcon = (iconName: string, className: string = "w-6 h-6") => {
    switch (iconName) {
      case "wind":
        return (
          <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
        );
      case "square":
        return (
          <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16v12H4z" />
          </svg>
        );
      case "compress":
        return (
          <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l4 4m12-4v4m0-4h-4m4 0l-4 4M4 16v4m0 0h4m-4 0l4-4m12 4v-4m0 4h-4m4 0l-4-4" />
          </svg>
        );
      case "brain":
        return (
          <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
        );
      case "music":
        return (
          <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
          </svg>
        );
      case "dumbbell":
        return (
          <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14l7 7 7-7-7-7z" />
          </svg>
        );
      default:
        return null;
    }
  };

  const startTherapyModule = (module: TherapyModule) => {
    if (module.type === "breathing") {
      setActiveExercise(module.id);
    } else if (module.type === "sound" && module.audioUrl) {
      if (activeSoundModuleId === module.id && isPlaying) {
        setCurrentAudioUrl(null);
        setActiveSoundModuleId(null);
        toast({
          title: "Sound Stopped",
          description: `${module.title} has been paused.`,
        });
        return;
      }

      setActiveSoundModuleId(module.id);
      setCurrentAudioUrl(module.audioUrl);
      
      toast({
        title: `Playing ${module.title}`,
        description: "Enjoy the relaxing sounds. Click again to pause.",
      });

      createTherapySession.mutate({
        type: module.type,
        duration: module.duration,
        completed: false,
      });
    } else {
      toast({
        title: `Starting ${module.title}`,
        description: "Follow the guided instructions for this therapeutic session.",
      });
      
      createTherapySession.mutate({
        type: module.type,
        duration: module.duration,
        completed: false,
      });
    }
  };

  const stopSound = () => {
    setCurrentAudioUrl(null);
    setActiveSoundModuleId(null);
  };

  const onExerciseComplete = (exerciseId: string, duration: number) => {
    const module = therapyModules.find(m => m.id === exerciseId);
    if (module) {
      createTherapySession.mutate({
        type: module.type,
        duration,
        completed: true,
      });
      
      toast({
        title: "Session Complete",
        description: `Great job! You completed a ${duration}-minute ${module.title} session.`,
      });
    }
    setActiveExercise(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg font-semibold text-gray-600">Loading therapeutic modules...</p>
        </div>
      </div>
    );
  }

  if (activeExercise) {
    const exercise = therapyModules.find(m => m.id === activeExercise);
    if (exercise) {
      return (
        <BreathingExercise
          exerciseType={activeExercise}
          title={exercise.title}
          onComplete={(duration) => onExerciseComplete(activeExercise, duration)}
          onExit={() => setActiveExercise(null)}
        />
      );
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <audio ref={audioRef} className="hidden" preload="none" />
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        <Card className="shadow-lg border-gray-100">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Therapeutic Modules</h1>
                <p className="text-gray-600">Explore healing techniques and pain relief strategies</p>
              </div>
              {isPlaying && activeSoundModule && (
                <Button
                  onClick={stopSound}
                  variant="outline"
                  className="text-red-600 border-red-200 hover:bg-red-50"
                  data-testid="button-stop-sound"
                >
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
                  </svg>
                  Stop {activeSoundModule.title}
                </Button>
              )}
            </div>

            <div className="flex flex-wrap gap-4 mb-8">
              {[
                { id: "meditation", label: "Meditation", icon: "leaf" },
                { id: "sound", label: "Sound Therapy", icon: "music" },
                { id: "exercise", label: "Exercise", icon: "dumbbell" },
              ].map((category) => (
                <Button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  variant={activeCategory === category.id ? "default" : "outline"}
                  className={`px-6 py-2 rounded-full font-medium flex items-center space-x-2 ${
                    activeCategory === category.id
                      ? "gradient-bg text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                  data-testid={`button-category-${category.id}`}
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    {category.icon === "leaf" && (
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                    )}
                    {category.icon === "music" && (
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                    )}
                    {category.icon === "dumbbell" && (
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14l7 7 7-7-7-7z" />
                    )}
                  </svg>
                  <span>{category.label}</span>
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredModules.map((module) => (
                <Card
                  key={module.id}
                  className={`therapy-card bg-gradient-to-br ${module.gradient} p-6 ${module.borderColor} cursor-pointer hover:shadow-lg transition-all duration-300 ${
                    activeSoundModuleId === module.id && isPlaying ? "ring-2 ring-blue-500" : ""
                  }`}
                  onClick={() => startTherapyModule(module)}
                  data-testid={`card-therapy-${module.id}`}
                >
                  <CardContent className="p-0">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-12 h-12 gradient-bg rounded-xl flex items-center justify-center text-white">
                        {getIcon(module.icon)}
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-gray-900">{module.title}</h3>
                        <p className="text-sm text-gray-600">{module.description}</p>
                      </div>
                      {activeSoundModuleId === module.id && isPlaying && (
                        <div className="ml-auto">
                          <div className="flex space-x-1">
                            <div className="w-1 h-4 bg-blue-500 rounded animate-pulse"></div>
                            <div className="w-1 h-6 bg-blue-500 rounded animate-pulse" style={{ animationDelay: "150ms" }}></div>
                            <div className="w-1 h-3 bg-blue-500 rounded animate-pulse" style={{ animationDelay: "300ms" }}></div>
                            <div className="w-1 h-5 bg-blue-500 rounded animate-pulse" style={{ animationDelay: "450ms" }}></div>
                          </div>
                        </div>
                      )}
                    </div>
                    <p className="text-gray-700 mb-4">
                      {module.type === "breathing" && "Learn calming breathing techniques to reduce stress and manage pain naturally."}
                      {module.type === "relaxation" && "Progressive muscle relaxation helps release physical tension and promote healing."}
                      {module.type === "meditation" && "Guided meditation sessions designed specifically for pain management and emotional well-being."}
                      {module.type === "sound" && "Soothing sounds to help you relax, reduce stress, and ease pain symptoms."}
                      {module.type === "exercise" && "Gentle exercises designed to improve mobility and reduce pain."}
                    </p>
                    <Button className="w-full bg-white/50 hover:bg-white/70 text-gray-900 font-medium transition-colors">
                      {module.type === "breathing" ? "Start Breathing Exercise" : 
                       module.type === "sound" ? (activeSoundModuleId === module.id && isPlaying ? "Playing..." : "Play Sound") :
                       `Start ${module.duration}-min Session`}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredModules.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <svg className="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p>No modules found in this category.</p>
              </div>
            )}

            <div className="mt-8 bg-gradient-to-r from-purple-100 to-blue-100 rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">Today's Recommended Practice</h3>
                  <p className="text-gray-600 mb-4">
                    Based on your recent pain patterns, we recommend starting with gentle breathing exercises.
                  </p>
                  <Button
                    onClick={() => startTherapyModule(therapyModules[0])}
                    className="gradient-bg text-white px-6 py-2 hover:opacity-90"
                    data-testid="button-start-recommended"
                  >
                    Start Recommended Session
                  </Button>
                </div>
                <div className="w-20 h-20 bg-white/30 rounded-full flex items-center justify-center">
                  <svg className="w-10 h-10 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
