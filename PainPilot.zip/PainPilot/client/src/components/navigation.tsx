import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const { user } = useAuth();

  return (
    <nav className="gradient-bg text-white p-4 shadow-lg sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19 14.5v-9c0-.83-.67-1.5-1.5-1.5H12v2h5v8.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5zM6.5 4C5.67 4 5 4.67 5 5.5v9c0 .83.67 1.5 1.5 1.5S8 15.33 8 14.5V6h4V4H6.5z"/>
              <path d="M12.5 11c-.28 0-.5.22-.5.5s.22.5.5.5.5-.22.5-.5-.22-.5-.5-.5zm0-2c-.28 0-.5.22-.5.5s.22.5.5.5.5-.22.5-.5-.22-.5-.5-.5z"/>
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold">MediCare AI</h1>
            <p className="text-sm opacity-90">Intelligent Pain Management</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="hidden md:flex items-center space-x-6">
            <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full">
              <svg className="w-4 h-4 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/>
              </svg>
              <span className="text-xs font-medium">HIPAA Compliant</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full">
              <svg className="w-4 h-4 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"/>
              </svg>
              <span className="text-xs font-medium">256-bit Encryption</span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            {user?.profileImageUrl && (
              <img
                src={user.profileImageUrl}
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover border-2 border-white/20"
              />
            )}
            <div className="hidden md:block text-right">
              <p className="text-sm font-medium">
                {user?.firstName || user?.email}
              </p>
              <Button
                variant="link"
                className="text-xs text-white/80 p-0 h-auto hover:text-white"
                onClick={() => window.location.href = "/api/logout"}
              >
                Sign out
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
