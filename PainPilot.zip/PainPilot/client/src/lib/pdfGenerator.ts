import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { PainEntry } from '@shared/schema';
import html2canvas from 'html2canvas';

interface AnalyticsData {
  totalEntries: number;
  averagePain: number;
  painFreeDays: number;
  areaDistribution: Array<{ area: string; percentage: number }>;
  dailyTrends: Array<{ date: string; averagePain: number; mood: string }>;
}

export async function generateAndDownloadReport(
  painEntries: PainEntry[],
  analytics: AnalyticsData,
  chartElement?: HTMLElement
): Promise<void> {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const lineHeight = 8;
  let y = 20;

  // Header
  pdf.setFontSize(16);
  pdf.text('MediCare AI – Pain Summary Report', 105, y, { align: 'center' });
  y += 10;

  // Summary
  pdf.setFontSize(12);
  pdf.text(`Total Entries: ${analytics.totalEntries}`, 20, y); y += lineHeight;
  pdf.text(`Average Pain Level: ${analytics.averagePain.toFixed(1)}/10`, 20, y); y += lineHeight;
  pdf.text(`Pain-Free Days: ${analytics.painFreeDays}`, 20, y); y += lineHeight;

  // Area Distribution Table
  y += 5;
  autoTable(pdf, {
    startY: y,
    head: [['Area', 'Percentage']],
    body: analytics.areaDistribution.map(item => [item.area, `${item.percentage.toFixed(1)}%`]),
    styles: { fontSize: 10 },
    margin: { left: 20, right: 20 },
    headStyles: { fillColor: [59, 130, 246] }
  });

  y = (pdf as any).lastAutoTable.finalY + 10;

  // Daily Trends Chart as Image (optional)
  if (chartElement) {
    const canvas = await html2canvas(chartElement);
    const imgData = canvas.toDataURL('image/png');
    pdf.addPage();
    pdf.setFontSize(13);
    pdf.text('Pain Trend Chart', 20, 20);
    pdf.addImage(imgData, 'PNG', 15, 30, 180, 100);
    y = 140;
  }

  // Detailed Logs
  pdf.addPage();
  pdf.setFontSize(13);
  pdf.text('Detailed Pain Entries', 20, 20);
  autoTable(pdf, {
    startY: 30,
    head: [['Date', 'Area', 'Level', 'Type', 'Duration', 'Mood', 'Notes']],
    body: painEntries.map(entry => [
      new Date(entry.createdAt || new Date()).toLocaleDateString(),
      entry.painArea,
      `${entry.intensity}/10`,
      entry.painType,
      entry.duration,
      entry.mood || '',
      entry.notes?.slice(0, 30) || ''
    ]),
    styles: { fontSize: 9 },
    margin: { left: 20, right: 20 },
    headStyles: {
      fillColor: [59, 130, 246],
      textColor: [255, 255, 255]
    }
  });

  // Footer on all pages
  const totalPages = pdf.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    pdf.setFontSize(10);
    pdf.text(`Page ${i} of ${totalPages} – MediCare AI`, 105, 290, { align: 'center' });
  }

  pdf.save('pain-report.pdf');
}
