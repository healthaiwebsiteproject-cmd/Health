import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY
});

export async function getAIPainManagementResponse(
  message: string,
  userContext?: {
    recentPainLevel?: number;
    commonPainArea?: string;
    painHistory?: Array<{ intensity: number; area: string; date: string }>;
  }
): Promise<string> {
  try {
    const systemPrompt = `You are a compassionate AI pain management assistant. You provide evidence-based, supportive guidance for pain management. Always:

1. Show empathy and understanding
2. Provide practical, safe pain management techniques
3. Suggest when to seek professional medical help
4. Never diagnose or prescribe medication
5. Focus on holistic approaches like breathing, relaxation, gentle movement
6. Encourage tracking and understanding pain patterns

IMPORTANT: Always remind users that you are not a replacement for professional medical care and they should consult healthcare providers for serious concerns.`;

    let contextualPrompt = message;
    
    if (userContext) {
      contextualPrompt = `User context: 
      - Recent average pain level: ${userContext.recentPainLevel || 'Not available'}/10
      - Most common pain area: ${userContext.commonPainArea || 'Not specified'}
      - Pain history: ${userContext.painHistory?.length || 0} recent entries
      
      User message: ${message}`;
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: contextualPrompt }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response at this time. Please try again.";
  } catch (error) {
    console.error("Error calling OpenAI:", error);
    if (!process.env.OPENAI_API_KEY) {
      return "I'm currently unavailable as the AI service needs to be configured. Please contact support or consult with a healthcare professional for immediate concerns.";
    }
    return "I'm experiencing technical difficulties right now. Please try again in a moment. If you're experiencing severe pain, please consider contacting a healthcare professional.";
  }
}

export async function generatePainReport(
  painData: {
    averagePain: number;
    totalEntries: number;
    painFreeDays: number;
    commonArea: string;
    painTrends: Array<{ date: string; avgPain: number; count: number }>;
    areaDistribution: Array<{ area: string; count: number; percentage: number }>;
  },
  timeframe: string = "30 days"
): Promise<{
  summary: string;
  insights: string[];
  recommendations: string[];
}> {
  try {
    const prompt = `Generate a pain management report based on this data from the last ${timeframe}:
    
    - Average pain level: ${painData.averagePain}/10
    - Total pain entries: ${painData.totalEntries}
    - Pain-free days: ${painData.painFreeDays}
    - Most common pain area: ${painData.commonArea}
    - Pain area distribution: ${JSON.stringify(painData.areaDistribution)}
    
    Please provide:
    1. A brief summary of the pain patterns
    2. Key insights about pain trends
    3. Evidence-based recommendations for pain management
    
    Format as JSON with: { "summary": "...", "insights": ["...", "..."], "recommendations": ["...", "..."] }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 800,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      summary: result.summary || "Pain data analysis unavailable.",
      insights: result.insights || [],
      recommendations: result.recommendations || []
    };
  } catch (error) {
    console.error("Error generating pain report:", error);
    if (!process.env.OPENAI_API_KEY) {
      return {
        summary: "AI analysis is currently unavailable due to configuration issues.",
        insights: ["Pain tracking data is being recorded successfully"],
        recommendations: ["Continue monitoring your pain levels", "Consult with healthcare professionals for persistent pain"]
      };
    }
    return {
      summary: "Unable to generate detailed analysis at this time.",
      insights: ["Data analysis temporarily unavailable"],
      recommendations: ["Continue tracking your pain daily", "Consult with healthcare providers for personalized advice"]
    };
  }
}
